package com.shriganda.contact.web;

import com.shriganda.contact.model.Contact;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@WebServlet(urlPatterns = {"/contacts", "/contacts/add"})
public class ContactServlet extends HttpServlet {
    private static final String CONTACTS = "contacts";
    private static final String FORM_TOKEN = "formToken";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();

        if ("/contacts/add".equals(path)) {
            HttpSession session = request.getSession();
            if (session.getAttribute(FORM_TOKEN) == null) {
                session.setAttribute(FORM_TOKEN, UUID.randomUUID().toString());
            }
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp")
                    .forward(request, response);
            return;
        }

        HttpSession session = request.getSession();
        List<Contact> contacts = getContacts(session);

        request.setAttribute("contacts", contacts);
        request.getRequestDispatcher("/WEB-INF/views/contact-list.jsp")
                .forward(request, response);
    }

    @SuppressWarnings("unchecked")
    private List<Contact> getContacts(HttpSession session) {
        Object value = session.getAttribute(CONTACTS);

        if (value == null) {
            List<Contact> contacts = new ArrayList<>();
            session.setAttribute(CONTACTS, contacts);
            return contacts;
        }

        return (List<Contact>) value;
    }
}
