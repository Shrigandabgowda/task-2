package com.shriganda.contact.web;

import com.shriganda.contact.model.Contact;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/contacts")
public class AddContactServlet extends HttpServlet {
    private static final String CONTACTS = "contacts";
    private static final String FORM_TOKEN = "formToken";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        String submittedToken = trim(request.getParameter("formToken"));
        String sessionToken = (String) session.getAttribute(FORM_TOKEN);

        // Prevent accidental duplicate form submissions.
        if (sessionToken == null || !sessionToken.equals(submittedToken)) {
            request.setAttribute("error", "The form has expired or was already submitted. Please try again.");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp")
                    .forward(request, response);
            return;
        }

        String name = trim(request.getParameter("name"));
        String email = trim(request.getParameter("email"));
        String phone = trim(request.getParameter("phone"));

        List<String> errors = new ArrayList<>();

        if (name.isEmpty() || name.length() < 2 || name.length() > 50) {
            errors.add("Please enter valid name");
        }

        if (email.isEmpty() || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            errors.add("Invalid email address");
        }

        if (!phone.isEmpty() && !phone.matches("^\\d{10}$")) {
            errors.add("Use 10-digit format");
        }

        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.setAttribute("name", name);
            request.setAttribute("email", email);
            request.setAttribute("phone", phone);
            request.setAttribute("error", "Please correct the highlighted fields.");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp")
                    .forward(request, response);
            return;
        }

        try {
            @SuppressWarnings("unchecked")
            List<Contact> contacts =
                    (List<Contact>) session.getAttribute(CONTACTS);

            if (contacts == null) {
                contacts = new ArrayList<>();
                session.setAttribute(CONTACTS, contacts);
            }

            int nextId = contacts.stream()
                    .mapToInt(Contact::getId)
                    .max()
                    .orElse(0) + 1;

            contacts.add(new Contact(nextId, name, email, phone));

            // Rotate token after successful submission.
            session.setAttribute(FORM_TOKEN, java.util.UUID.randomUUID().toString());
            session.setAttribute("success", "Contact added successfully.");

            response.sendRedirect(request.getContextPath() + "/contacts");

        } catch (NullPointerException e) {
            request.setAttribute("error", "Unable to process the contact. Please try again.");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp")
                    .forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "A server error occurred. Please try again.");
            request.getRequestDispatcher("/WEB-INF/views/contact-form.jsp")
                    .forward(request, response);
        }
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }
}
