document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contactForm");
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const spinner = document.getElementById("spinner");
    const submitBtn = document.getElementById("submitBtn");

    function validateName() {
        const value = name.value.trim();
        const error = document.getElementById("nameError");

        if (value.length < 2 || value.length > 50) {
            error.textContent = "Please enter valid name";
            name.classList.add("invalid");
            return false;
        }

        error.textContent = "";
        name.classList.remove("invalid");
        return true;
    }

    function validateEmail() {
        const value = email.value.trim();
        const error = document.getElementById("emailError");
        const pattern = /^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$/;

        if (!pattern.test(value)) {
            error.textContent = "Invalid email address";
            email.classList.add("invalid");
            return false;
        }

        error.textContent = "";
        email.classList.remove("invalid");
        return true;
    }

    function validatePhone() {
        const value = phone.value.trim();
        const error = document.getElementById("phoneError");

        if (value !== "" && !/^\d{10}$/.test(value)) {
            error.textContent = "Use 10-digit format";
            phone.classList.add("invalid");
            return false;
        }

        error.textContent = "";
        phone.classList.remove("invalid");
        return true;
    }

    name.addEventListener("input", validateName);
    email.addEventListener("input", validateEmail);
    phone.addEventListener("input", validatePhone);

    form.addEventListener("submit", (event) => {
        const validName = validateName();
        const validEmail = validateEmail();
        const validPhone = validatePhone();

        if (!(validName && validEmail && validPhone)) {
            event.preventDefault();

            const firstInvalid = form.querySelector(".invalid");
            if (firstInvalid) firstInvalid.focus();
            return;
        }

        submitBtn.disabled = true;
        spinner.classList.remove("hidden");
    });

    name.focus();
});
