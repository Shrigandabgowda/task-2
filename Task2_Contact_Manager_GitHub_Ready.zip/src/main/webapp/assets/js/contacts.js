document.addEventListener("DOMContentLoaded", () => {
    const table = document.getElementById("contactTable");
    if (!table) return;

    const searchInput = document.getElementById("searchInput");
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    const pageInfo = document.getElementById("pageInfo");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");

    const pageSize = 5;
    let page = 1;
    let filteredRows = rows;

    function render() {
        const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
        if (page > totalPages) page = totalPages;

        rows.forEach(row => row.style.display = "none");

        const start = (page - 1) * pageSize;
        filteredRows.slice(start, start + pageSize)
            .forEach(row => row.style.display = "");

        pageInfo.textContent = `Page ${page} of ${totalPages}`;
        prevBtn.disabled = page === 1;
        nextBtn.disabled = page === totalPages;
    }

    searchInput.addEventListener("input", () => {
        const query = searchInput.value.toLowerCase().trim();

        filteredRows = rows.filter(row =>
            row.textContent.toLowerCase().includes(query)
        );

        page = 1;
        render();
    });

    prevBtn.addEventListener("click", () => {
        if (page > 1) {
            page--;
            render();
        }
    });

    nextBtn.addEventListener("click", () => {
        const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
        if (page < totalPages) {
            page++;
            render();
        }
    });

    render();
});
