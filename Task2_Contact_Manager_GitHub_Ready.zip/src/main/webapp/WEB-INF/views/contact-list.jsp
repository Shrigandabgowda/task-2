<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<div class="container">
    <header class="topbar">
        <div>
            <h1>Contact Manager</h1>
            <p>Admin contact management</p>
        </div>
        <a class="btn primary" href="${pageContext.request.contextPath}/contacts/add">+ Add New Contact</a>
    </header>

    <c:if test="${not empty sessionScope.success}">
        <div id="toast" class="toast success"><c:out value="${sessionScope.success}"/></div>
        <c:remove var="success" scope="session"/>
    </c:if>

    <main class="card">
        <div class="toolbar">
            <input id="searchInput" type="search"
                   placeholder="Search contacts..." aria-label="Search contacts">
        </div>

        <c:choose>
            <c:when test="${empty contacts}">
                <div class="empty">No contacts</div>
            </c:when>
            <c:otherwise>
                <div class="table-wrap">
                    <table id="contactTable">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="contact" items="${contacts}">
                            <tr>
                                <td><c:out value="${contact.id}"/></td>
                                <td><c:out value="${contact.name}"/></td>
                                <td><c:out value="${contact.email}"/></td>
                                <td><c:out value="${contact.phone}"/></td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>

                <div class="pagination">
                    <button class="btn secondary" id="prevBtn" type="button">Previous</button>
                    <span id="pageInfo"></span>
                    <button class="btn secondary" id="nextBtn" type="button">Next</button>
                </div>
            </c:otherwise>
        </c:choose>
    </main>
</div>

<script src="${pageContext.request.contextPath}/assets/js/contacts.js"></script>
</body>
</html>
