<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Contact</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<div class="container">
    <header class="topbar">
        <div>
            <h1>Contact Manager</h1>
            <p>Add a new contact</p>
        </div>
        <a class="btn secondary" href="${pageContext.request.contextPath}/contacts">View Contacts</a>
    </header>

    <main class="card">
        <c:if test="${not empty error}">
            <div class="alert error"><c:out value="${error}"/></div>
        </c:if>

        <c:if test="${not empty errors}">
            <div class="alert error">
                <ul>
                    <c:forEach var="item" items="${errors}">
                        <li><c:out value="${item}"/></li>
                    </c:forEach>
                </ul>
            </div>
        </c:if>

        <form id="contactForm"
              action="${pageContext.request.contextPath}/contacts"
              method="post"
              novalidate>

            <input type="hidden" name="formToken" value="${sessionScope.formToken}">

            <div class="form-group">
                <label for="name">Name</label>
                <input id="name" name="name" value="<c:out value='${name}'/>"
                       minlength="2" maxlength="50" required>
                <small id="nameError" class="field-error"></small>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input id="email" type="email" name="email"
                       value="<c:out value='${email}'/>" required>
                <small id="emailError" class="field-error"></small>
            </div>

            <div class="form-group">
                <label for="phone">Phone</label>
                <input id="phone" name="phone"
                       value="<c:out value='${phone}'/>"
                       maxlength="10" inputmode="numeric">
                <small id="phoneError" class="field-error"></small>
            </div>

            <button id="submitBtn" class="btn primary" type="submit">
                Add Contact
            </button>
            <span id="spinner" class="spinner hidden"></span>
        </form>
    </main>
</div>

<script src="${pageContext.request.contextPath}/assets/js/validation.js"></script>
</body>
</html>
